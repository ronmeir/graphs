ques_eight
% The function ques_eight runs the all implemented taks.
%it runs the RPG function for 30 iterations for both T1 (1) and T2 (2) for
% n=5:5:100. the function also generates the graphs.
