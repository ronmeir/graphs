function [] = Graph()
SimulationT1(30)
SimulationT2(30)
func()

end

