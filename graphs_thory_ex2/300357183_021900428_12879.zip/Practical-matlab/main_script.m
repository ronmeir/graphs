%Q7 - will start the simultaion for T1 and T2 properties
%NOTE: this simulation will print 30*20 average time (according to T1 or T2
%property).
Q7(30,@T1) 
Q7(30,@T2)
%Q8 - plotting the graphs of a,b and c
Draw_graph(30)