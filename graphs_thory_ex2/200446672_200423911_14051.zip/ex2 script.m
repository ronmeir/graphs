n=5:5:100;
figure;hold on ;plot(n,timeof(1),'blue',n,timeof(2),'red',n,0.5*n.*(log(n)),'green')%T1-blue, T2-Red, f-Green