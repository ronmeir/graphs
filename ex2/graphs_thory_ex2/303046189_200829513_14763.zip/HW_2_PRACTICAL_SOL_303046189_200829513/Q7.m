function [] = Q7(K,T)
for n=5:5:100,
    for i=1:K,
         [~,t]=RGP(n,T)
    end
end

