%Yaniv Costica - 303046189
%Osher Yohanan - 200829513
%Question7 - will start the simultaion for T1 and T2 properties
%NOTE: this simulation will print 30*20 average time (according to T1 or T2
%property).
Question7(30,@T1) 
Question7(30,@T2)
%Question8 - plotting the graphs of a,b and c
Draw_graph(30)